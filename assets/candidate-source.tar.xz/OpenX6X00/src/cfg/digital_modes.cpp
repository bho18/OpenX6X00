// digital_modes.cpp
// Implementation of the C API for digital mode (FT8/FT4) preset navigation.
//
// This is the C++/C API boundary: it reads the current front-panel frequency
// from the global SettingsManager (cfg_sm), queries the preset through
// DigitalModesTable (db.h/db.cpp) and writes the found frequency/mode back
// through the computed params cp_fg_freq / cp_cur_mode (their reverse paths
// write into the active VFO band params and trigger mode/band switching).

#include "digital_modes.h"
#include "../freedv/mode.h"
#include "../freedv/writer_gate.h"

#include <atomic>
#include <cstdio>
#include <string>

#include "db.h"
#include "settings_manager.h"

namespace {

// Label of the last successfully loaded preset; retained only until the next
// successful load (matches the legacy C module's strdup'ed label).
std::string last_label;

// Its frequency, read by the web remote's thread
std::atomic<int32_t> last_freq{0};

} // namespace

extern "C" bool cfg_digital_load(int8_t dir, cfg_digital_type_t type) {
    int32_t cur_freq = cfg_sm.cp_fg_freq.get();

    DigitalModesTable::LoadResult result;
    if (dir > 0) {
        result = DigitalModesTable::find_next(type, cur_freq);
    } else if (dir == 0) {
        result = DigitalModesTable::find_closest(type, cur_freq);
    } else {
        result = DigitalModesTable::find_prev(type, cur_freq);
    }
    if (result.rc != SUCCESS) {
        return false;
    }

#ifdef ENABLE_FREEDV_VOICE
    if(freedv_mode_active() && !fd_writer_voice_authorized()) {
        return type == CFG_DIG_TYPE_FREEDV && freedv_mode_request(FD_LOCAL_FREQUENCY,result.value.freq);
    }
#endif
    last_label = result.value.label;
    last_freq  = result.value.freq;
    cfg_sm.cp_fg_freq.set(result.value.freq);
    if (type != CFG_DIG_TYPE_FREEDV) cfg_sm.cp_cur_mode.set(result.value.mode);
    return true;
}

extern "C" const char *cfg_digital_label_get(void) {
    return last_label.c_str();
}

extern "C" int32_t cfg_digital_freq_get(void) {
    return last_freq;
}

extern "C" int cfg_digital_list(cfg_digital_type_t type, cfg_digital_preset_t *out, int max) {
    int n = 0;

    for (int32_t f = 0; n < max; n++) {
        auto r = DigitalModesTable::find_next(type, f);
        if (r.rc != SUCCESS) {
            break;
        }
        f           = r.value.freq;
        out[n].freq = f;
        snprintf(out[n].label, sizeof(out[n].label), "%s", r.value.label.c_str());
    }
    return n;
}

extern "C" int cfg_digital_count(cfg_digital_type_t type) {return DigitalModesTable::count(type);}
extern "C" bool cfg_digital_bookmark_save(int32_t old_frequency,int32_t frequency,const char *label) {
    return DigitalModesTable::save_bookmark(CFG_DIG_TYPE_FREEDV,old_frequency,frequency,label);
}
extern "C" bool cfg_digital_bookmark_delete(int32_t frequency) {return DigitalModesTable::erase_bookmark(CFG_DIG_TYPE_FREEDV,frequency);}
