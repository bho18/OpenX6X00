// SPDX-License-Identifier: LGPL-2.1-or-later
#pragma once
#include <stdbool.h>
#include <stdint.h>
typedef enum { FD_VS_OFF, FD_VS_PREPARING, FD_VS_RX, FD_VS_TX_STARTING, FD_VS_TX,
    FD_VS_TX_DRAIN, FD_VS_FAULT, FD_VS_WAIT_PTT_RELEASE, FD_VS_EXITING } fd_voice_state;
typedef enum { FD_PTT_RADIO, FD_PTT_HAND, FD_PTT_SOURCES } fd_ptt_source;
typedef enum { FD_ABORT_NONE, FD_ABORT_STOP, FD_ABORT_TIMEOUT, FD_ABORT_HEALTH,
    FD_ABORT_DEVICE, FD_ABORT_DRAIN, FD_ABORT_PROTECTION, FD_ABORT_START_RELEASE } fd_abort_reason;
typedef enum { FD_BENCH_DISARMED, FD_BENCH_ARMED, FD_BENCH_READY } fd_bench_grant;
typedef struct {
    bool valid, pressed;
    uint64_t sequence, monotonic_ms;
    uint64_t release_sequence; /* retained physical releases, not poll sequence */
} fd_ptt_observation;
typedef struct {
    bool valid, tx, protection, device_error;
    uint64_t sequence, monotonic_ms;
    fd_ptt_observation ptt[FD_PTT_SOURCES];
} fd_voice_observation;
typedef enum { FD_LOCAL_FREQUENCY, FD_LOCAL_BAND, FD_LOCAL_VFO, FD_LOCAL_VOLUME, FD_LOCAL_MEMORY,
    FD_LOCAL_POWER, /* tenths of a watt, 1..100 */
    FD_LOCAL_STEP   /* positive: next step; zero/negative: previous step */
} fd_local_operation;
typedef struct {
    int32_t frequency;
    unsigned vfo;
    fd_local_operation operation;
    int32_t request_value;
} fd_voice_tuning;
typedef struct {
    fd_voice_state state;
    fd_abort_reason fault;
    uint64_t generation, turns;
    unsigned timeout_seconds;
    bool ptt_held[FD_PTT_SOURCES], ptt_unknown[FD_PTT_SOURCES];
    bool synchronized, microphone_active, exit_requested;
    bool validation;
    fd_bench_grant bench_grant;
    uint64_t grant_deadline_ms, grants_consumed;
    fd_voice_tuning tuning;
} fd_voice_status;
