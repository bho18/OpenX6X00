// SPDX-License-Identifier: LGPL-2.1-or-later
#define _POSIX_C_SOURCE 200809L
#include "voice_audio.h"
#include "../audio.h"
#include "../board.h"
#include <pthread.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <stdio.h>
struct fd_voice_audio {
    pthread_mutex_t lock;
    pthread_cond_t changed;
    pthread_t pump;
    bool started, shutdown, active, busy, finishing, finish_sent, drain_sent, capture_owned;
    uint64_t pump_last_ms;
    unsigned pump_gap_ms, device_observe_ms;
    uint64_t generation;
    uint64_t adapter_instance, engine_instance, capture_instance, playback_instance;
    unsigned rate;
    bool directional_audio;
    fd_profile_audio_map rx_audio, tx_audio, selected_audio;
    fd_voice_direction direction;
    atomic_bool cancelled, failed;
    atomic_uint microphone_peak;
    atomic_uint cancel_epoch;
    atomic_uint first_fault;
    atomic_ullong fault_generation, fault_ms, attempted_generation;
    atomic_uint fault_capture_queued, fault_engine_input_depth;
    fd_voice_engine *engine;
    audio_freedv_playback_t *playback;
    int16_t pending[480];
    size_t count, offset;
    fd_voice_audio_snapshot snapshot;
    uint64_t previous_tx_generation, previous_tx_input_samples, previous_tx_first_write_ns, previous_tx_underflows;
    bool previous_tx_finished;
    void (*on_error)(void *);
    void *error_context;
    fd_voice_audio_taps taps;
};
static atomic_uint_fast64_t resource_sequence;
static uint64_t resource_instance(void) {return atomic_fetch_add(&resource_sequence,1)+1;}
static uint64_t now(void) {struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return (uint64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
static void pause_ms(void) {struct timespec t={0,2000000};nanosleep(&t,NULL);}
static bool capture_stalled(audio_freedv_capture_stats_t s, bool admitting) {
    if(!s.started_ms)return false;
    /* Keep late-callback evidence latched even if delivery resumes before
     * this worker runs. Time spent draining after admission closes is idle,
     * not a missing capture callback. Allow device startup one second. */
    if(s.first_callback_delay_ms>1000 || s.longest_inter_callback_gap_ms>500)return true;
    return admitting && (unsigned)now()-(s.callbacks?s.last_callback_ms:s.started_ms)>(s.callbacks?500u:1000u);
}
void fd_voice_audio_cancel(fd_voice_audio *a) {
    if(!a)return;
    atomic_fetch_add(&a->cancel_epoch,1);
    atomic_store(&a->cancelled,true);
    fd_voice_cancel(a->engine);
    audio_freedv_playback_request_cancel(a->playback);
}
static void failure_with_depth(fd_voice_audio *a,unsigned reason,unsigned capture_queued,unsigned engine_depth) {
    unsigned expected=FD_AUDIO_OK;
    if(atomic_compare_exchange_strong(&a->first_fault,&expected,reason)){
        atomic_store(&a->fault_generation,atomic_load(&a->attempted_generation));
        atomic_store(&a->fault_ms,now());
        atomic_store(&a->fault_capture_queued,capture_queued);
        atomic_store(&a->fault_engine_input_depth,engine_depth);
    }
    if(!atomic_exchange(&a->failed,true)){
        fprintf(stderr,"FreeDV audio fault %u, generation %llu\n",reason,(unsigned long long)a->generation);
        if(a->on_error)a->on_error(a->error_context);
    }
    fd_voice_audio_cancel(a);
}
static void failure_at(fd_voice_audio *a,unsigned reason) {
    failure_with_depth(a,reason,audio_freedv_capture_stats().queued_samples,fd_voice_observe(a->engine).input_depth);
}
static void snapshot_locked(fd_voice_audio *a) {
    uint64_t before=now();
    audio_freedv_playback_stats_t playback=audio_freedv_playback_observe(a->playback);
    unsigned waited=(unsigned)(now()-before);
    if(waited>a->device_observe_ms)a->device_observe_ms=waited;
    a->snapshot=(fd_voice_audio_snapshot){.sampled_ms=now(),.generation=a->generation,
        .adapter_instance=a->adapter_instance,.engine_instance=a->engine_instance,
        .capture_instance=a->capture_instance,.playback_instance=a->playback_instance,
        .capture_channel=a->directional_audio ? a->selected_audio.capture_channel : 0,
        .playback_channel=a->directional_audio ? a->selected_audio.playback_channel : 0,
        .cancelled=atomic_load(&a->cancelled),.failed=atomic_load(&a->failed),.finishing=a->finishing,
        .first_fault=atomic_load(&a->first_fault),.fault_generation=atomic_load(&a->fault_generation),
        .fault_capture_queued=atomic_load(&a->fault_capture_queued),.fault_engine_input_depth=atomic_load(&a->fault_engine_input_depth),
        .fault_ms=atomic_load(&a->fault_ms),.engine=fd_voice_observe(a->engine),
        .capture=audio_freedv_capture_stats(),.playback=playback,
        .pump_gap_ms=a->pump_gap_ms,.device_observe_ms=a->device_observe_ms,
        .previous_tx_generation=a->previous_tx_generation,.previous_tx_input_samples=a->previous_tx_input_samples,
        .previous_tx_first_write_ns=a->previous_tx_first_write_ns,.previous_tx_underflows=a->previous_tx_underflows,
        .previous_tx_finished=a->previous_tx_finished};
}
/* Submit PCM which is already ready before sleeping again. One short device
 * write used to incur the full 2 ms pump delay, even if both the rest of the
 * modem block and device space were available. Bound work by calls and PCM,
 * stop immediately on device backpressure, and keep every accepted sample's
 * offset so this neither pads nor drops a partial write. No extra startup
 * block or output queue is introduced. The caller holds the admission lock. */
static void submit_ready_output(fd_voice_audio *a) {
    size_t submitted=0,budget=a->rate/5;
    for(unsigned attempt=0;attempt<64 && submitted<budget && !atomic_load(&a->cancelled);++attempt) {
        if(a->offset==a->count) {
            size_t request=a->rate/100;
            if(request>budget-submitted)request=budget-submitted;
            a->count=fd_voice_receive(a->engine,a->generation,a->pending,request);a->offset=0;
        }
        if(a->offset==a->count)break;
        size_t request=a->count-a->offset;
        if(request>budget-submitted)request=budget-submitted;
        ssize_t accepted=audio_freedv_playback_submit_generation(a->playback,a->generation,a->pending+a->offset,request);
        if(accepted<0) {
            if(!atomic_load(&a->cancelled))failure_at(a,FD_AUDIO_WRITE);
            break;
        }
        if(!accepted)break;
        if(a->taps.output)a->taps.output(a->taps.context,a->pending+a->offset,(size_t)accepted);
        a->offset+=(size_t)accepted;submitted+=(size_t)accepted;
    }
}
static void *pump(void *arg) {
    fd_voice_audio *a=arg;pthread_mutex_lock(&a->lock);
    while(!a->shutdown) {
        while(!a->shutdown && (!a->active || atomic_load(&a->cancelled)))pthread_cond_wait(&a->changed,&a->lock);
        if(a->shutdown)break;
        a->busy=true;
        uint64_t tick=now();
        if(a->pump_last_ms && tick-a->pump_last_ms>a->pump_gap_ms)a->pump_gap_ms=(unsigned)(tick-a->pump_last_ms);
        a->pump_last_ms=tick;
        /* The lock is the admission fence for finish/fence. No radio lock is
         * taken here, and cancel is independent of this lock and PA progress. */
        int16_t input[480], stereo[960];
        size_t n=audio_freedv_capture_read(input,a->rate/100);
        int64_t sum=0;unsigned peak=0;
        for(size_t i=0;i<n;++i)sum+=input[i];
        int mean=n?(int)(sum/(int64_t)n):0;
        for(size_t i=0;i<n;++i){int ac=(int)input[i]-mean;unsigned level=(unsigned)(ac<0?-ac:ac);if(level>peak)peak=level;}
        size_t stereo_frames=audio_freedv_capture_read_stereo(stereo,a->rate/100);
        if(stereo_frames && a->taps.stereo)a->taps.stereo(a->taps.context,stereo,stereo_frames*2);
        audio_freedv_capture_stats_t capture=audio_freedv_capture_stats();
        fd_voice_stats queued=fd_voice_observe(a->engine);
        atomic_store(&a->microphone_peak,a->direction==FD_VOICE_TX && queued.input_samples>=a->rate/5?peak:0);
        if(capture.capture_errors || capture.dropped_samples || capture.hole_samples)failure_at(a,FD_AUDIO_CAPTURE);
        else if(capture_stalled(capture,!a->finishing))
            failure_with_depth(a,FD_AUDIO_CAPTURE_STALL,capture.queued_samples,queued.input_depth);
        else if(capture.queued_samples!=UINT_MAX && (uint64_t)capture.queued_samples+queued.input_depth>a->rate/2)
            failure_with_depth(a,FD_AUDIO_BACKLOG,capture.queued_samples,queued.input_depth);
        if(atomic_load(&a->cancelled))goto telemetry;
        size_t submitted=n?fd_voice_submit(a->engine,a->generation,input,n):0;
        if(submitted && a->taps.input)a->taps.input(a->taps.context,input,submitted);
        if(submitted!=n && !atomic_load(&a->cancelled)){
            fd_voice_stats failed=fd_voice_observe(a->engine);
            fprintf(stderr,"FreeDV rejected %zu input samples; generation %llu engine %llu, depth %u, failures %u, cancelled %u\n",n,
                (unsigned long long)a->generation,(unsigned long long)failed.generation,failed.input_depth,failed.failures,failed.cancelled);
            failure_at(a,FD_AUDIO_INPUT_REJECTED);
        }
        if(atomic_load(&a->cancelled))goto telemetry;
        if(a->finishing && !n && !a->finish_sent) {
            if(!fd_voice_finish(a->engine,a->generation))failure_at(a,FD_AUDIO_FINISH);
            a->finish_sent=true;
        }
        submit_ready_output(a);
telemetry:;
        fd_voice_stats engine=fd_voice_observe(a->engine);
        if(engine.failures)failure_at(a,FD_AUDIO_ENGINE);
        if(!atomic_load(&a->cancelled) && a->finish_sent && engine.finished && !engine.output_depth && a->offset==a->count && !a->drain_sent) {
            if(!audio_freedv_playback_drain(a->playback,a->generation))failure_at(a,FD_AUDIO_DRAIN);
            a->drain_sent=true;
        }
        uint64_t sampled=now();
        if(atomic_load(&a->failed) || a->snapshot.generation!=a->generation || sampled-a->snapshot.sampled_ms>=100){
            snapshot_locked(a);
            if(a->snapshot.playback.stream_failed){
                failure_at(a,FD_AUDIO_STREAM);
                snapshot_locked(a);
            }
        }
        a->busy=false;pthread_cond_broadcast(&a->changed);pthread_mutex_unlock(&a->lock);
        pause_ms();pthread_mutex_lock(&a->lock);
    }
    pthread_mutex_unlock(&a->lock);return NULL;
}
static fd_voice_audio *voice_audio_open(const fd_qualified_profile *profile,bool diagnostic) {
    /* The existing capture source is fixed by board.h. Reject incompatible
     * descriptors instead of silently using the wrong endpoint or boundary. */
    if(!profile || !profile->capture_device || !profile->playback_device || !profile->mixer)return NULL;
    if(!diagnostic && (!fd_profile_audio_map_valid(profile->rx_audio) ||
                       !fd_profile_audio_map_valid(profile->tx_audio)))return NULL;
#if defined(FREEDV_HOST_TEST_PROFILE) || defined(HOST_BUILD)
    if(strcmp(profile->capture_device,"@default-source@") || strcmp(profile->playback_device,"@default-sink@") ||
        strcmp(profile->mixer,"host-default") || profile->sample_rate!=AUDIO_CAPTURE_RATE)return NULL;
#else
    if(
        !BOARD_PA_SOURCE || !BOARD_PA_SINK || profile->sample_rate!=AUDIO_CAPTURE_RATE ||
        strcmp(profile->capture_device,BOARD_PA_SOURCE) || strcmp(profile->playback_device,BOARD_PA_SINK))return NULL;
#endif
    fd_voice_audio *a=calloc(1,sizeof(*a));if(!a)return NULL;
    if(pthread_mutex_init(&a->lock,NULL)){free(a);return NULL;}
    if(pthread_cond_init(&a->changed,NULL)){pthread_mutex_destroy(&a->lock);free(a);return NULL;}
    atomic_init(&a->cancelled,true);atomic_init(&a->failed,false);atomic_init(&a->microphone_peak,0);atomic_init(&a->cancel_epoch,0);a->rate=profile->sample_rate;
    atomic_init(&a->first_fault,FD_AUDIO_OK);atomic_init(&a->fault_generation,0);atomic_init(&a->fault_ms,0);
    atomic_init(&a->attempted_generation,0);
    atomic_init(&a->fault_capture_queued,0);atomic_init(&a->fault_engine_input_depth,0);
    a->directional_audio=!diagnostic;a->rx_audio=profile->rx_audio;a->tx_audio=profile->tx_audio;
    a->selected_audio=diagnostic ? (fd_profile_audio_map){.capture_channel=profile->capture_channel} : profile->rx_audio;
#if defined(FREEDV_HOST_TEST_PROFILE) || defined(HOST_BUILD)
    if(!audio_freedv_capture_configure(a->selected_audio.capture_channel,NULL))goto error;
#else
    if(!audio_freedv_capture_configure(a->selected_audio.capture_channel,profile->mixer))goto error;
#endif
    if(!audio_freedv_voice_capture_open())goto error;
    a->capture_owned=true;a->capture_instance=resource_instance();
    a->engine=fd_voice_create(profile->sample_rate);
    if(a->engine)a->engine_instance=resource_instance();
    a->playback=diagnostic ? audio_freedv_playback_open() :
        audio_freedv_playback_open_mapped(a->selected_audio.playback_channel);
    if(a->playback)a->playback_instance=resource_instance();
    if(!a->engine || !a->playback)goto error;
    if(pthread_create(&a->pump,NULL,pump,a))goto error;
    a->started=true;a->adapter_instance=resource_instance();return a;
error:
    fd_voice_audio_close(a);return NULL;
}
fd_voice_audio *fd_voice_audio_open(const fd_qualified_profile *profile) {return voice_audio_open(profile,false);}
fd_voice_audio *fd_voice_audio_open_diagnostic(const fd_qualified_profile *profile) {return voice_audio_open(profile,true);}
bool fd_voice_audio_fence(fd_voice_audio *a) {
    if(!a)return false;fd_voice_audio_cancel(a);
    pthread_mutex_lock(&a->lock);a->active=false;
    audio_freedv_capture_end();a->count=a->offset=0;
    if(a->direction==FD_VOICE_TX && a->generation){
        fd_voice_stats engine=fd_voice_observe(a->engine);
        audio_freedv_playback_stats_t playback=audio_freedv_playback_observe(a->playback);
        a->previous_tx_generation=a->generation;a->previous_tx_input_samples=engine.input_samples;
        a->previous_tx_first_write_ns=playback.generation_first_write_ns;
        a->previous_tx_underflows=playback.generation_underflows;a->previous_tx_finished=engine.finished;
    }
    pthread_mutex_unlock(&a->lock);
    /* The cancellation fence rejects all writes, and acknowledged flush
     * removes accepted output. Keep the empty stream uncorked while owned:
     * corking allows the sink to auto-suspend between turns, putting device
     * resume work back inside the next keyed capture boundary. No idle PCM
     * is written. Closing the adapter releases the device normally. */
    if(!audio_freedv_playback_cancel(a->playback))return false;
    uint64_t deadline=now()+500;
    while(!audio_freedv_playback_quiescent(a->playback) && now()<deadline)pause_ms();
    bool quiet=audio_freedv_playback_quiescent(a->playback);
    /* Export acknowledged device state, not the last running pump snapshot. */
    pthread_mutex_lock(&a->lock);snapshot_locked(a);pthread_mutex_unlock(&a->lock);
    return quiet;
}
static bool startup_allowed(fd_voice_audio *a,unsigned epoch,fd_voice_audio_admit_fn admit,void *context) {
    return epoch==atomic_load(&a->cancel_epoch) && !atomic_load(&a->failed) && (!admit || admit(context));
}
bool fd_voice_audio_begin_guarded(fd_voice_audio *a,fd_voice_direction direction,uint64_t generation,
        fd_voice_audio_admit_fn admit,void *context) {
    if(!a || (direction!=FD_VOICE_RX && direction!=FD_VOICE_TX) || atomic_load(&a->failed))return false;
    atomic_store(&a->attempted_generation,generation);
    unsigned epoch=atomic_load(&a->cancel_epoch);
    /* Driver applies/key-selects the qualified route first. Flush at that
     * actual boundary, then admit only fresh microphone/RF samples. */
    if(!startup_allowed(a,epoch,admit,context)){fd_voice_audio_cancel(a);return false;}
    if(!audio_freedv_capture_flush_begin()) {
        if(!startup_allowed(a,epoch,admit,context)){fd_voice_audio_cancel(a);return false;}
        failure_at(a,FD_AUDIO_CAPTURE_FLUSH);return false;
    }
    uint64_t deadline=now()+500;
    while(!audio_freedv_capture_flushed() && now()<deadline){
        if(!startup_allowed(a,epoch,admit,context)){fd_voice_audio_cancel(a);return false;}
        pause_ms();
    }
    if(!startup_allowed(a,epoch,admit,context)){fd_voice_audio_cancel(a);return false;}
    if(audio_freedv_capture_flushed()!=1) { failure_at(a,FD_AUDIO_CAPTURE_FLUSH_TIMEOUT); return false; }
    pthread_mutex_lock(&a->lock);
    unsigned reason=FD_AUDIO_REARM;
    bool rejected=!startup_allowed(a,epoch,admit,context);
    bool ok=!a->active && generation>a->generation;
    ok &= !rejected;
    if(ok && a->directional_audio) {
        /* Both streams retain stereo framing. Only the application slot
         * changes, while capture admission is closed and output is flushed. */
        fd_profile_audio_map map=direction==FD_VOICE_RX ? a->rx_audio : a->tx_audio;
        reason=FD_AUDIO_CHANNEL_MAP;
        ok=audio_freedv_capture_configure(map.capture_channel,NULL) &&
            audio_freedv_playback_select_channel(a->playback,map.playback_channel);
        if(ok)a->selected_audio=map;
    }
    if(!startup_allowed(a,epoch,admit,context)){rejected=true;ok=false;}
    if(ok){reason=FD_AUDIO_TRANSITION;ok=fd_voice_transition(a->engine,direction,generation);}
    if(!startup_allowed(a,epoch,admit,context)){rejected=true;ok=false;}
    if(ok){reason=FD_AUDIO_PLAYBACK_REARM;ok=audio_freedv_playback_rearm(a->playback,generation);}
    if(!startup_allowed(a,epoch,admit,context)){rejected=true;ok=false;}
    if(ok){reason=FD_AUDIO_CAPTURE_BEGIN;ok=audio_freedv_capture_begin();}
    if(!startup_allowed(a,epoch,admit,context)){rejected=true;ok=false;}
    if(ok){
        a->generation=generation;a->direction=direction;a->finishing=a->finish_sent=a->drain_sent=false;
        a->pump_last_ms=now();a->pump_gap_ms=a->device_observe_ms=0;
        atomic_store(&a->microphone_peak,0);atomic_store(&a->cancelled,false);
        /* Pump admission is still locked: a concurrent Stop cannot be erased
         * by rearm, even if it arrived during a PA callback/engine transition. */
        if(!startup_allowed(a,epoch,admit,context)){rejected=true;ok=false;}
        else {a->active=true;pthread_cond_broadcast(&a->changed);}
    }
    if(!ok){fd_voice_audio_cancel(a);audio_freedv_capture_end();}
    pthread_mutex_unlock(&a->lock);
    if(!ok && !rejected)failure_at(a,reason);
    return ok;
}
bool fd_voice_audio_begin(fd_voice_audio *a,fd_voice_direction direction,uint64_t generation) {
    return fd_voice_audio_begin_guarded(a,direction,generation,NULL,NULL);
}
bool fd_voice_audio_finish(fd_voice_audio *a,uint64_t generation) {
    if(!a)return false;pthread_mutex_lock(&a->lock);
    bool ok=a->active && a->direction==FD_VOICE_TX && generation==a->generation && !atomic_load(&a->cancelled);
    if(ok){audio_freedv_capture_end();a->finishing=true;}
    pthread_mutex_unlock(&a->lock);return ok;
}
int fd_voice_audio_drained(fd_voice_audio *a) {
    if(!a || atomic_load(&a->failed) || atomic_load(&a->cancelled))return -1;
    pthread_mutex_lock(&a->lock);int status=a->drain_sent?audio_freedv_playback_drained(a->playback,a->generation):0;
    pthread_mutex_unlock(&a->lock);return status;
}
bool fd_voice_audio_failed(fd_voice_audio *a) {return !a || atomic_load(&a->failed);}
bool fd_voice_audio_set_taps(fd_voice_audio *a,const fd_voice_audio_taps *taps) {
    if(!a)return false;pthread_mutex_lock(&a->lock);bool ok=!a->active;
    if(ok)a->taps=taps?*taps:(fd_voice_audio_taps){0};
    pthread_mutex_unlock(&a->lock);return ok;
}
void fd_voice_audio_on_error(fd_voice_audio *a,void (*handler)(void *),void *context) {
    if(!a)return;pthread_mutex_lock(&a->lock);a->on_error=handler;a->error_context=context;pthread_mutex_unlock(&a->lock);
}
bool fd_voice_audio_snapshot_get(fd_voice_audio *a,fd_voice_audio_snapshot *out) {
    if(!a || !out || pthread_mutex_trylock(&a->lock))return false;
    bool valid=a->snapshot.sampled_ms && a->snapshot.generation==a->generation;
    if(valid){*out=a->snapshot;out->cancelled=atomic_load(&a->cancelled);out->failed=atomic_load(&a->failed);}
    pthread_mutex_unlock(&a->lock);return valid;
}
bool fd_voice_audio_microphone_active(fd_voice_audio *a) {return a && !atomic_load(&a->cancelled) && atomic_load(&a->microphone_peak)>120;}
fd_voice_stats fd_voice_audio_observe(fd_voice_audio *a) {return fd_voice_observe(a?a->engine:NULL);}
void fd_voice_audio_close(fd_voice_audio *a) {
    if(!a)return;fd_voice_audio_cancel(a);pthread_mutex_lock(&a->lock);a->shutdown=true;
    pthread_cond_broadcast(&a->changed);pthread_mutex_unlock(&a->lock);
    if(a->started)pthread_join(a->pump,NULL);
    audio_freedv_capture_end();
    audio_freedv_capture_flush_close();
    if(a->capture_owned)audio_freedv_voice_capture_close();
    (void)audio_freedv_capture_configure(0,NULL);
    if(a->playback)audio_freedv_playback_close(a->playback);
    fd_voice_destroy(a->engine);pthread_cond_destroy(&a->changed);pthread_mutex_destroy(&a->lock);free(a);
}
