/**
 * @file fbdev.c
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include "fbdev.h"
#if USE_FBDEV || USE_BSD_FBDEV

#include <stdlib.h>
#include <unistd.h>
#include <stddef.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <semaphore.h>
#include <arm_neon.h>

#if USE_BSD_FBDEV
#include <sys/fcntl.h>
#include <sys/time.h>
#include <sys/consio.h>
#include <sys/fbio.h>
#else  /* USE_BSD_FBDEV */
#include <linux/fb.h>
#endif /* USE_BSD_FBDEV */

/*********************
 *      DEFINES
 *********************/
#ifndef FBDEV_PATH
#define FBDEV_PATH  "/dev/fb0"
#endif

#ifndef DIV_ROUND_UP
#define DIV_ROUND_UP(n, d) (((n) + (d) - 1) / (d))
#endif


/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *      STRUCTURES
 **********************/

struct bsd_fb_var_info{
    uint32_t xoffset;
    uint32_t yoffset;
    uint32_t xres;
    uint32_t yres;
    int bits_per_pixel;
 };

struct bsd_fb_fix_info{
    long int line_length;
    long int smem_len;
};

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void rotate_area(const lv_area_t *area, const uint32_t *src);

/**********************
 *  STATIC VARIABLES
 **********************/
#if USE_BSD_FBDEV
static struct bsd_fb_var_info vinfo;
static struct bsd_fb_fix_info finfo;
#else
static struct fb_var_screeninfo vinfo;
static struct fb_fix_screeninfo finfo;
#endif /* USE_BSD_FBDEV */
static char *fbp = 0;
static long int screensize = 0;
static int fbfd = 0;


/**********************
 *      MACROS
 **********************/

#if USE_BSD_FBDEV
#define FBIOBLANK FBIO_BLANK
#endif /* USE_BSD_FBDEV */

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

void fbdev_init(void)
{
    // Open the file for reading and writing
    fbfd = open(FBDEV_PATH, O_RDWR);
    if(fbfd == -1) {
        perror("Error: cannot open framebuffer device");
        return;
    }
    LV_LOG_INFO("The framebuffer device was opened successfully");

    // Make sure that the display is on.
    if (ioctl(fbfd, FBIOBLANK, FB_BLANK_UNBLANK) != 0) {
        perror("ioctl(FBIOBLANK)");
        return;
    }

#if USE_BSD_FBDEV
    struct fbtype fb;
    unsigned line_length;

    //Get fb type
    if (ioctl(fbfd, FBIOGTYPE, &fb) != 0) {
        perror("ioctl(FBIOGTYPE)");
        return;
    }

    //Get screen width
    if (ioctl(fbfd, FBIO_GETLINEWIDTH, &line_length) != 0) {
        perror("ioctl(FBIO_GETLINEWIDTH)");
        return;
    }

    vinfo.xres = (unsigned) fb.fb_width;
    vinfo.yres = (unsigned) fb.fb_height;
    vinfo.bits_per_pixel = fb.fb_depth;
    vinfo.xoffset = 0;
    vinfo.yoffset = 0;
    finfo.line_length = line_length;
    finfo.smem_len = finfo.line_length * vinfo.yres;
#else /* USE_BSD_FBDEV */

    // Get fixed screen information
    if(ioctl(fbfd, FBIOGET_FSCREENINFO, &finfo) == -1) {
        perror("Error reading fixed information");
        return;
    }

    // Get variable screen information
    if(ioctl(fbfd, FBIOGET_VSCREENINFO, &vinfo) == -1) {
        perror("Error reading variable information");
        return;
    }
#endif /* USE_BSD_FBDEV */

    LV_LOG_INFO("%dx%d, %dbpp", vinfo.xres, vinfo.yres, vinfo.bits_per_pixel);

    // Figure out the size of the screen in bytes
    screensize =  finfo.smem_len; //finfo.line_length * vinfo.yres;

    // Map the device to memory
    fbp = (char *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, fbfd, 0);
    if((intptr_t)fbp == -1) {
        perror("Error: failed to map framebuffer device to memory");
        return;
    }

    // Don't initialise the memory to retain what's currently displayed / avoid clearing the screen.
    // This is important for applications that only draw to a subsection of the full framebuffer.

    LV_LOG_INFO("The framebuffer device was mapped to memory successfully");


}

void fbdev_exit(void)
{
    munmap(fbp, screensize);
    close(fbfd);
}

/**
 * Flush a buffer to the marked area
 * @param drv pointer to driver where this function belongs
 * @param area an area where to copy `color_p`
 * @param color_p an array of pixels to copy to the `area` part of the screen
 */
void fbdev_flush(lv_disp_drv_t * drv, const lv_area_t * area, lv_color_t * color_p)
{
    if(fbp == NULL ||
            area->x2 < 0 ||
            area->y2 < 0 ||
            area->x1 > (int32_t)vinfo.yres - 1 ||
            area->y1 > (int32_t)vinfo.xres - 1) {
        lv_disp_flush_ready(drv);
        return;
    }

    rotate_area(area, (const uint32_t *)color_p);
    lv_disp_flush_ready(drv);
}

void fbdev_get_sizes(uint32_t *width, uint32_t *height, uint32_t *dpi) {
    if (width)
        *width = vinfo.xres;

    if (height)
        *height = vinfo.yres;

    if (dpi && vinfo.height)
        *dpi = DIV_ROUND_UP(vinfo.xres * 254, vinfo.width * 10);
}

void fbdev_set_offset(uint32_t xoffset, uint32_t yoffset) {
    vinfo.xoffset = xoffset;
    vinfo.yoffset = yoffset;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

/* The LVGL area (landscape, src is area-sized) rotated 90° counter-clockwise
 * straight into the portrait framebuffer: pixel (x, y) goes to row
 * yres - 1 - x, column y. 4x4 blocks with NEON, the edges one by one */
static void rotate_area(const lv_area_t *area, const uint32_t *src) {
    uint32_t       *fb     = (uint32_t *)fbp;
    int32_t         stride = finfo.line_length / 4;
    int32_t         last   = (int32_t)vinfo.yres - 1;
    int32_t         w      = area->x2 - area->x1 + 1;
    int32_t         x1     = LV_MAX(area->x1, 0);
    int32_t         x2     = LV_MIN(area->x2, last);
    int32_t         y1     = LV_MAX(area->y1, 0);
    int32_t         y2     = LV_MIN(area->y2, (int32_t)vinfo.xres - 1);
    int32_t         y;

    if (vinfo.bits_per_pixel != 32 || x1 > x2 || y1 > y2) {
        return;
    }
    for (y = y1; y + 3 <= y2; y += 4) {
        const uint32_t *r = src + (y - area->y1) * w - area->x1;
        int32_t         x = x1;

        for (; x + 3 <= x2; x += 4) {
            uint32x4x2_t t0 = vtrnq_u32(vld1q_u32(r + x), vld1q_u32(r + w + x));
            uint32x4x2_t t1 = vtrnq_u32(vld1q_u32(r + 2 * w + x), vld1q_u32(r + 3 * w + x));
            uint32_t    *d  = fb + (last - x) * stride + y;

            vst1q_u32(d,              vcombine_u32(vget_low_u32(t0.val[0]),  vget_low_u32(t1.val[0])));
            vst1q_u32(d - stride,     vcombine_u32(vget_low_u32(t0.val[1]),  vget_low_u32(t1.val[1])));
            vst1q_u32(d - 2 * stride, vcombine_u32(vget_high_u32(t0.val[0]), vget_high_u32(t1.val[0])));
            vst1q_u32(d - 3 * stride, vcombine_u32(vget_high_u32(t0.val[1]), vget_high_u32(t1.val[1])));
        }
        for (; x <= x2; x++) {
            uint32_t *d = fb + (last - x) * stride + y;

            d[0] = r[x];
            d[1] = r[w + x];
            d[2] = r[2 * w + x];
            d[3] = r[3 * w + x];
        }
    }
    for (; y <= y2; y++) {
        const uint32_t *r = src + (y - area->y1) * w - area->x1;

        for (int32_t x = x1; x <= x2; x++) {
            fb[(last - x) * stride + y] = r[x];
        }
    }
}

#endif
